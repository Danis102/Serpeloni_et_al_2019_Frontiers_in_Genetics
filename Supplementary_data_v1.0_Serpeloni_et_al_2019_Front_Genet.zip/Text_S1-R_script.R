######################################################################################
## This script was written by Dr Daniel N�tt
## Version 1.1 02/10/2019
##
##--------------------------------------------------------------------------------##
####          Initial notes
##--------------------------------------------------------------------------------##
## These script will automatically generate some of the key results reported
## in Serpeloni et al 2019 (Frontiers in Genetics)
##
## All file inputs needed to perform the methylome switching analysis in the 
## Brazilian (target population for the current paper) and the publically 
## available African American Grady dataset, are available in the file 
## 'Start_files.zip' which was published as a supplementary to 
## Serpeloni et al. 2019 (Frontiers in Genetics).
##
## Especially the Grady analysis is hardware demanding. The script worked fine on   
## a desktop computer having a i7-3930K 3.2GHz CPU with 48 GB of RAM, but failed on 
## a laptop having a i5-4210U CPU 2.4GHz with 8GB of RAM.
##
## Info about a functional session environment is listed in the end of this script. 
## The script are especially depending on:
## R version 3.5.1, GEOquery 2.48.0, minfi 1.26.2, reshape 0.8.7, limma 3.36.3,
## ggplot2 3.0.0, IlluminaHumanMethylation450kanno.ilmn12.hg19 0.6.0      
## IlluminaHumanMethylation450kmanifest 0.4.0
##
## Important: Sharing raw data from the Brazilian samples are regulated by 
## strict ethical protocols/permits to protect children and women living in criminal 
## environments. Therefore, we can only provide anonymized beta-values of the 
## 1% top differentially methylated CpGs. By doing so we abolish the risk that 
## unauthorized persons may extract genetic fingerprints from the data. While   
## such possibility exists if providing raw data, the analytical pipeline that 
## was used here to generate the top 1% tables has been optimized for the     
## removal of microarray probes that may carry genetic information. This optimization
## was done in three steps:
##		(1) Specific SNP probes on the array was omitted. 	
##		(2)	We disregard CpG probes that overlap with genomic regions known to have
##			  common polymorphism, as described in Chen et al. 2013 (Epigenetics, 8, 203-9).  	
##		(3) We use robust statistics, which is a common method to minimize the effect of 
##			  outliers. Since polymorphism often appears as data outliers, by using
##			  robust statistics we minimize the number of probes that may unintentionally
##			  hold genetic information in the 1% top tables. For more about this see Fig. S4.
##
## It must be noted that the Brazilian raw data can be acquired by contacting the main
## authors of this paper, but will be subjected to individual written consents, and 
## assurance that all research done on the material will follow the ethical protocols.  
##
## Nevertheless, by downloading the freely available Grady dataset from Gene Expression 
## Omnibus (GEO) anyone that which to validate the pipeline that we used to generate the 
## top 1% table from the Brazilian subjects may do so using the Grady dataset.  
##
## Lastly, we also provide scripts that will perform the novel methylome switching 
## on the Brazilian and Grady datasets side-by-side using the top 1% differentially 
## methylated CpGs of each dataset.
##
## We hope you will find our scripts useful. If you encounter any problems with the script
## please contact Dr Daniel N�tt, on daniel.natt@liu.se.
## or check Daniel's github for possible script updates: https://github.com/Danis102
##
##############################################################################################



##--------------------------------------------------------------------------------##
####          Load required files from Supplement_data.zip 
##--------------------------------------------------------------------------------##

# Start by setting a working directory were Supplement_Data.zip is stored
setwd("C:/Users/danis31/OneDrive - Link�pings universitet/Skriverier/Konstanz - Manuscript 1/My drafts/Frontiers in Genetics/Reviewers comments/Updated files/Sent to Fernada and Thomas/Ready for resubmission/Proof_1/Test supp 2")
setwd("<#### Path to your working directory ####>")

# File containing the EWAS results and beta values of the 1% top differentially methyalted CpGs of the Brazilian children and women.  
Braz_res <- read.delim(unz("Supplement_data.zip", "Data_S1-Res_Braz_top_1perc_2019-01-24.xls"), header=T, quote="\"")

# Phenotype data (e.g. IPV category, Sex, Age etc) from the Brazilian children and women. 
Pheno_Braz <- read.delim(unz("Supplement_data.zip", "Data_S2-Pheno_start_2019-01-24.xls"), header=T, quote="\"")

# Phenotype data from the publically available Grady study used for validating finding in the Brazilian samples. 
Pheno_Grady <- read.delim(unz("Supplement_data.zip", "Data_S3-Pheno_grady_cleaned.txt"), header=T, quote="\"")

# A list of bead chip probes that are discarded due to known polymorphism or cross-hybirdization as described by Chen et al. 2013 (Epigenetics, 8, 203-9). 
Chen_excluded_probes <- read.delim(unz("Supplement_data.zip", "Data_S4-Chen_et_al_excluded_probes.txt"), header=T, quote="\"")


##--------------------------------------------------------------------------------##
####          Function to download and prepare Grady dataset from GEO
##--------------------------------------------------------------------------------##
## Description:
##			This function will download the a supplementary file from GEO 
##			(accession number: GSE72680) containing raw data from the Grady study.
##			Please see script text output for details.	
## Input:
##			Data S3 - Pheno_grady = File containing the cleaned up phenotype data from the Grady study.  
##			path = path to a destination fold for the Grady download.  
## Output:			
##			A list containing 
##			 (1) a MethylSet object with raw signals and phenotype data from Grady. 
##			 (2) a table with detection p-values obtained from GEO.	
##


get.grady <- function(path, Pheno_Grady){
				suppressWarnings(require("GEOquery", quietly = TRUE))
				suppressWarnings(require("minfi", quietly = TRUE))
				response <- readline(prompt=cat("\nThis will create a new directory in your output path:\n    ",path,"\n\nIs it ok to proceed? [y/n]"))
				if(response=="y" | response=="Y"){
					cat("\nDownloading and preparing grady methylation data (GEO accession number: GSE72680).")
					cat("\nDepending on your hardware and connection, it will take some time.\n")
					cat(paste0("Download started: ", Sys.time(), "\n")) 
					dir.create(paste0(path, "/grady"))
					getGEOSuppFiles("GSE72680", makeDirectory = FALSE, 
									baseDir = paste0(path, "/grady"), 
									fetch_files = TRUE, 
									filter_regex="GSE72680_signals.txt.gz")
					cat(paste0("Decompress and read raw signal file: ", Sys.time(), "\n"))
					con <- gzfile(paste0(path, "/grady/", "GSE72680_signals.txt.gz"), "GSE72680_signals.txt")  # Open a gzip connection to to be used with read.delim
					signals <- read.delim(con, header=T)
					close(con)  # Avoids and later warning when connection closes 
					cat(paste0("\nRaw signal file has successfully been loaded: ", Sys.time(), "\n"))
					colnames(signals) <- gsub("X","", colnames(signals))
					detect_p<- as.matrix(signals[,grepl("Detection", names(signals))])      # Must be matrix if preprocessQuantile should work
					meth<- as.matrix(signals[,grepl("Methylated", names(signals))]) 
					unmeth<- as.matrix(signals[,grepl("Unmethylated", names(signals))]) 
					colnames(detect_p) <- gsub("_Detection.PVal","", colnames(detect_p))
					colnames(meth) <- gsub("_Methylated.signal","", colnames(meth))
					colnames(unmeth) <- gsub("_Unmethylated.signal","", colnames(unmeth))
					rownames(detect_p) <- signals[,1]
					rownames(meth) <- signals[,1]
					rownames(unmeth) <- signals[,1]
					if(identical(colnames(detect_p), colnames(meth))==FALSE){stop("ID's are not identical!")}
					if(identical(colnames(detect_p), colnames(unmeth))==FALSE){stop("ID's are not identical!")}
					if(identical(colnames(detect_p), colnames(unmeth))==FALSE){stop("ID's are not identical!")}
					Grady_list <- list(meth=meth, unmeth=unmeth, detect_p=detect_p)
					rownames(Pheno_Grady) <- Pheno_Grady$array_ID
					Grady_list_match <- lapply(Grady_list, function(x){x[, match(rownames(Pheno_Grady), colnames(x))]}) # In Pheno_Grady incomplete treatment data has been omitted. Match IDs with Pheno_Grady is need.    
					if(identical(colnames(Grady_list_match[[1]]), as.character(Pheno_Grady$array_ID))==FALSE){stop("ID's in Pheno_Grady are not identical with downloaded files!")}
					cat(paste0("n= ", as.character(ncol(Grady_list[[1]])), " samples in downloaded grady dataset.\n"))
					cat(paste0("n= ", as.character(ncol(Grady_list[[1]]) - ncol(Grady_list_match[[1]])), " samples were incomplete on whether undergone psychiatric treatment.\n"))
					cat(paste0("n= ", as.character(ncol(Grady_list_match[[1]])), " samples were retained for downstream analysis.\n"))
					pheno_done <- as(Pheno_Grady, "AnnotatedDataFrame")
					Mset <- MethylSet(Meth=Grady_list_match$meth, Unmeth = Grady_list_match$unmeth, colData = Pheno_Grady)
					Mset@preprocessMethod <- c(rg.norm = "Raw (no normalization or bg correction)", minfi = as.character(packageVersion("minfi")), manifest = "0.4.0")
					annotation(Mset) <- c(array="IlluminaHumanMethylation450k", annotation="ilmn12.hg19")
					detect_p_sort <- Grady_list_match$detect_p
					fin_lst <- list(MethylSet=Mset, Detection_pvalue=detect_p_sort)
					return(fin_lst)
					cat(paste0("MethylSet finished at: ", Sys.time())) 
				}
}

path="<#### Path to to where you want to download Grady study ####>"
Mset_list_grady <- get.grady(path, Pheno_Grady)


##--------------------------------------------------------------------------------##
####          Filter and function for the grady study
##--------------------------------------------------------------------------------##
## Description:
##			This function will perform all preprossessing steps used for all 
##			datasets. We use the Grady study as an example, since the raw data 	
##			from the Brazilian samples are protected by ethical protocol/permits.
##			Please see script text output for details.
## Input files:
##			Mset_list= Mset and detect_p list from the get.grady function above.
##			Data S3 - Chen_excluded_probes = Table with excluded probes from Chen et al. 2013 (Epigenetics, 8, 203-9).
## Output:			
##			A list containing 
##			 (1) a MethylSet object with raw signals and phenotype data from Grady. 
##			 (2) a table with detection p-values obtained from GEO.

filt.grady <- function(Mset_list, Filter_file){
				require("IlluminaHumanMethylation450kmanifest", quietly = TRUE)
				require("IlluminaHumanMethylation450kanno.ilmn12.hg19", quietly = TRUE)
				require("minfi", quietly = TRUE)
				require("limma", quietly = TRUE)
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat(paste0("This will perform preprocessing and differential methylation analysis on the Grady dataset.\n"))
				cat(paste0("The exact same pipeline was used for the main Brazilian datasets.\n"))
				cat(paste0("Preprocessing started.\n"))	
				Mset <- Mset_list[[1]]
				det_p <- Mset_list[[2]]
				if(identical(colnames(Mset), colnames(det_p))==FALSE){stop("Sample ID's in detection p file are not identical with MethylSet!")}
				if(identical(rownames(Mset), rownames(det_p))==FALSE){stop("CpG IDs in detection p file are not identical with MethylSet!")}
				cat("\n##---------------------------------------------------------------------------------------##\n")
				keep <- rowSums(det_p < 0.01) == ncol(Mset)
				Mset_detp <- Mset[keep,]  # 468939 (Braz: 270296)
				cat("Detection signal p-values came from the downloaded Grady project file.\n")
			 	cat("Probes with detection p-value <0.01 were retained:\n")
			 	cat(paste0(nrow(Mset_detp), " of ", nrow(Mset), " probes were retained.\n")) # 469613 367
			 	cat("\n##---------------------------------------------------------------------------------------##\n")
			 	Mset_detp_chen <- Mset_detp[!rownames(Mset_detp) %in% as.character(unique(Chen_excluded_probes$probe_ID)),]
			 	cat("As recommended by Chen et al. 2013 (Epigenetics, 8, 203-9) we removed non-specific probes (cross-reactive)") 
			 	cat("\nand probes within or close (+/-50pb) to SNPs having >= 1% allele frequency.")
			 	cat("\nLists for non-specifc probes can be found here:")
			 	cat("\nhttp://www.sickkids.ca/MS-Office-Files/Research/Weksberg%20Lab/48639-non-specific-probes-Illumina450k.xlsx")
			 	cat("\nLists for polymorphic probes can be found here:")
			 	cat("\nhttp://www.sickkids.ca/MS-Office-Files/Research/Weksberg%20Lab/48640-polymorphic-CpGs-Illumina450k.xlsx\n")
			 	cat(paste0(nrow(Mset_detp_chen), " of ", nrow(Mset_detp), " probes were retained.\n")) # 286549 367
			 	cat("\n##---------------------------------------------------------------------------------------##\n")
			 	cat("Now normalizing the filtered data using quantile normalization in the minfi package.\n")
			 	cat(paste0("Normalization started ", Sys.time(), "\n"))
			 	gset_filt <- suppressWarnings(preprocessQuantile(Mset_detp_chen, quantileNormalize=TRUE, stratified=TRUE, mergeManifest=TRUE, sex=NULL)) #Sex determination will not work on filtered dataset.
			 	cat("\n##---------------------------------------------------------------------------------------##\n")
			 	anno <- getAnnotation(gset_filt)
				anno_auto <- subset(anno, anno$chr!="chrX" & anno$chr!="chrY") 
				gset_final <- gset_filt[rownames(anno_auto),] 	
			 	cat("Since data contains males and females, we exclude CpGs on the sex chromosomes before proceeding with DM analysis.\n")
			 	cat(paste0(nrow(gset_final), " of ", nrow(gset_filt), " probes were retained.\n")) # 278664 367
			 	cat("\n##---------------------------------------------------------------------------------------##\n")
			 	cat("In total the filtration retained:\n")
			 	cat(paste0(nrow(gset_final), " of ", nrow(Mset), " probes.\n")) # 278664 367
			 	cat("\n##---------------------------------------------------------------------------------------##\n")
			 	cat("Now proceeding with DM analysis using the limma package.") 
			 	cat("\nA linear model was built using M-values as recommended by Du et al 2010 (BMC bioinformatics, 11, 587).")
			 	cat("\nFor the Grady dataset we used a very simple model: M-value= Psych + Sex + Age.")
			 	cat("\nPsych is the main factor, reporting whether the subject has been treated for a psychiatric disorder or not.")
			 	cat("\nAge and Sex was used as covariates.")
			 	cat("\nWe also used robust statistics in the lmFit function to minimize outlier effects possibly caused by rare SNPs.")
			 	cat("\nRobust statistics are hardware demanding, thus the calculations will take some time (approx 10 min; i7-3930K 3.2GHz processor, 48 GB RAM).")
			 	cat(paste0("\nModelling started: ", Sys.time()))
				design <- model.matrix (~ factor(pData(gset_final)$Psych) + factor(pData(gset_final)$Sex) + as.numeric(pData(gset_final)$Age)) 
				Mval <- getM(gset_final)
				fit <- lmFit(as.matrix(Mval), design,  maxit=250, method='robust')
				fit2 <- eBayes(fit)
				tt_grady <- topTable(fit2, coef=2, adjust="BH", sort.by="none", number=nrow(fit2))
			 	Beta_grady <- getBeta(gset_final)
				if(identical(rownames(pData(gset_final)), colnames(Beta_grady))==FALSE){stop("Sample IDs in Pheno data are not identical with Beta file!")}
				if(identical(rownames(tt_grady), rownames(Beta_grady))==FALSE){stop("CpG IDs in Beta file are not identical with statistical result file!")}
				Res_lst <- list(Pheno=pData(gset_final), Result=tt_grady, Beta=Beta_grady) 
			 	cat(paste0("\nScript finished at: ", Sys.time()))
			 	return(Res_lst)
				}
Grady_res <- filt.grady(Mset_list=Mset_list_grady, Filter_file=Chen_excluded_probes)


##--------------------------------------------------------------------------------##
####          Prepare data for methylome switching
##--------------------------------------------------------------------------------##
## Description:
##			This function will standardize the results from the Grady analysis
##			(as described above) and merge it with the results from Brazilian
##			women and children (as provided in 'Res_Braz_top_1perc_2019-01-24.xls').
##			Please see script text output for details.
## Input files:
##			Data S1 - Braz_res = 'Res_Braz_top_1perc_2019-01-24.xls' in Supplement_data.zip
##								      Contains the beta-values and EWAS results for 1% top CpGs
##								      Of the Brazilian women and children. 
##			Grady_res = Result list from filt.grady function (above) 
## Output:	
##			Multilevel list with with results ready for methylomes switching analysis.  
##

mswitch.prep <- function(Braz_res, Grady_res){
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("This function prepares the Brazilian and Grady data for methylome switching.\n")
				cat("First, we extract all CpGs that were among the 1% top in either the Brazilian women, children, or the Grady study.\n")
				cat("Note that we only analyze CpGs that have passed our filtering criteria (previous function) in all three (sub)populations.\n")
					All_sign_ID_Braz <- as.character(Braz_res[, 4])
					All_sign_across <- All_sign_ID_Braz[All_sign_ID_Braz %in% rownames(Grady_res[[2]])]  # These CpGs are avalable after filtering and among the 1% top in any of the dataset
				cat(paste0("There were ", length(All_sign_across), " CpGs in common across datasets.\n"))
					Grady_res[[2]] <- Grady_res[[2]][match(All_sign_across, rownames(Grady_res[[2]])),]
					Grady_res[[3]] <- Grady_res[[3]][match(All_sign_across, rownames(Grady_res[[3]])),]
					Braz_res <- Braz_res[match(All_sign_across, as.character(Braz_res$Name)),]
					rownames(Braz_res) <- as.character(Braz_res$Name)
					colnames(Braz_res) <- gsub("X9", "9", colnames(Braz_res))
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("Then we generate a standardized start list object with beta values from these CpGs.\n")
					common_anno <-  Braz_res[,!grepl("_child|_woman|logFC_|AveExpr_|P.Value_|adj.P.Val_", colnames(Braz_res))]
					Beta_c <- Braz_res[,grepl("_child", colnames(Braz_res))]
					Beta_w <- Braz_res[,grepl("_woman", colnames(Braz_res))]
					Beta_grady	<- as.data.frame(Grady_res[[3]])
				if(identical(rownames(Beta_c), rownames(Beta_w))==FALSE){stop("In grady data CpG IDs in Beta file are not identical with statistical result file!\n")}
				if(identical(rownames(Beta_grady), rownames(Beta_w))==FALSE){stop("Braz and Grady CpG IDs is not identical!\n")}
				if(identical(rownames(Beta_grady), rownames(common_anno))==FALSE){stop("CpG IDs in annotation is not identical to the beta files!\n")}
					lst_start <- list(Beta_Braz_child=Beta_c, Beta_Braz_women=Beta_w, Beta_Grady=Beta_grady)
				cat("Using this start list we calculate the mean methylation across all subject in each dataset.\n")
				cat("This value will be used to dived each dataset into CpGs with <50% or >50% methylation.\n")
				cat("We will also attatch information whether a CpG is within +/-50 bp of a repetative region.\n") 
				cat("CpG Repeat annotation is available in 'Res_Braz_top_1perc_2019-01-24.xls'.\n")
					lst_start_avrg <- lapply(lst_start, function(x){x$Average_meth <- ifelse(rowMeans(x) >= 0.5, "High", "Low"); return(x)})
					lst_start_avrg <- lapply(lst_start_avrg, function(x){x$Repeat <- ifelse(!common_anno$Repeat == "Repeat"|is.na(common_anno$Repeat), "No_repeat", "Repeat"); return(x)})
					CB_sign <- common_anno$Braz_c_1perc == "Yes" # 1% top CpGs Braz children  
					WB_sign <- common_anno$Braz_w_1perc == "Yes" # 1% top CpGs Braz women
					Grady_sign <- common_anno$Grady_1perc == "Yes" # 1% top CpGs Grady
					CB_lst <- lapply(lst_start_avrg, function(x){red_x <- x[CB_sign,];return(red_x)})				
					WB_lst <- lapply(lst_start_avrg, function(x){red_x <- x[WB_sign,];return(red_x)})
					Grady_lst <- lapply(lst_start_avrg, function(x){red_x <- x[Grady_sign,];return(red_x)})
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("When all factors have been collected we can generate CpG averages in the following categories:\n")
				cat("   (1) Averages of CpGs with more than 50% methylation and no repeat. \n")
				cat("   (2) Averages of CpGs with more than 50% methylation and in repeative region. \n")
				cat("   (3) Averages of CpGs with less than 50% methylation and no repeat. \n")
				cat("   (4) Averages of CpGs with less than 50% methylation and in repeative region.\n")
				cat("\nRemember that we generate these averages seperately for the 1% top DM CpGs identified in the\n") 
				cat("Brazilian children, Brazilain women and the grady study, respectively.\n")
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("The output list is structured like this:\n")
				cat("\n  list") 				
				cat("\n    |                                    |---Braz_child---Dataframe with (1-4)")
				cat("\n    |---sublist_1--top1%_Braz_children---|---Braz_women---Dataframe with (1-4)")
				cat("\n    |                                    |---Grady_psych--Dataframe with (1-4)")
				cat("\n    |")
				cat("\n    |                                    |---Braz_child---Dataframe with (1-4)")
				cat("\n    |---sublist_2--top1%_Braz_women------|---Braz_women---Dataframe with (1-4)")
				cat("\n    |                                    |---Grady_psych--Dataframe with (1-4)")
				cat("\n    |")	
				cat("\n    |                                    |---Braz_child---Dataframe with (1-4)")
				cat("\n    |---sublist_3--top1%_Grady_psych-----|---Braz_women---Dataframe with (1-4)")
				cat("\n                                         |---Grady_psych--Dataframe with (1-4)")
				cat("\n\n##---------------------------------------------------------------------------------------##\n")				
				funct <- function(x){new_tab <- aggregate(x[,1:(ncol(x)-2)], list(factor(paste(x$Average_meth, x$Repeat, sep="_"))), mean); return(new_tab)}
				CB_lst_aggr <-lapply(CB_lst, funct)
				WB_lst_aggr <-lapply(WB_lst, funct)
				Grady_lst_aggr <-lapply(Grady_lst, funct)
				fin_list<- list(top1_Braz_child=CB_lst_aggr, top1_Braz_women=WB_lst_aggr, top1_Grady=Grady_lst_aggr)
				return(fin_list)
			}
mswitch_lst <- mswitch.prep(Braz_res, Grady_res)

##--------------------------------------------------------------------------------##
####          Generates methylome switch plots
##--------------------------------------------------------------------------------##
## Descritption:
##			This will generate the plots from mswitch.prep using ggplot2.
##			Please see script text output for details.	
## Input files:
##			mswitch_lst = Multilevel list with prepped data for methylome switsching.
##			Data S2 - Pheno_Braz = Table containing phenotype data for Brazilian samples.
##			Data S3 - Pheno_Grady = Table containing phenotype data for the Grady study.		
## Output files:
##			Multilevel plot list. Each plot will also contain the results from a linear model.
##

Grady_res$Pheno -> Pheno_Grady

mswitch.plots <- function(mswitch_lst, Pheno_Braz, Pheno_Grady){
				require("reshape", quietly = TRUE, warn.conflicts = FALSE)
				require("ggplot2", quietly = TRUE, warn.conflicts = FALSE)
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("This function generates a plot list with methylome switching plots.\n")
				cat("First we check if the sample IDs in the mswitch list are ordered as in phenotype files.\n")
				cat("Then we restructure the data into a long format and build the plots using ggplots2.\n")
					rownames(Pheno_Braz) <- Pheno_Braz$Sample
					Pheno_Grady <- Pheno_Grady[,c("Psych",  "Sex", "Age")]
					Pheno_Braz$Mother_IPV <- ifelse(Pheno_Braz["Mother_IPV"]==1, "Prenatal_IPV", "Control")
					Pheno_Braz$Grandmother_IPV <- ifelse(Pheno_Braz["Grandmother_IPV"]==1, "Prenatal_IPV", "Control")
					pheno_list <- list(Braz_child=Pheno_Braz[Pheno_Braz$Generation == "child",], Braz_women=Pheno_Braz[Pheno_Braz$Generation == "mother",], Grady=Pheno_Grady)
					main_fact <- c("Mother_IPV", "Grandmother_IPV", "Psych")
					nam_dataset <- c("Brazilian_children", "Brazilian_women", "Psych_treatment_Grady")
					nam_top1 <- c("Top1%_Brazilian_children", "Top1%_Brazilian_women", "Top1%_Grady_study")
					covar_fact <- list(c("Age", "Sex", "Mother_CDV", "Mother_trauma"), c("Age", "Grandmother_CDV", "Grandmother_trauma"), c("Age", "Sex"))
					var <- c("High_Repeat", "High_No_repeat", "Low_Repeat", "Low_No_repeat")
					Fin_plot_lst <- list(NULL)
					for(i in 1:length(mswitch_lst)){
							sub_list <- mswitch_lst[[i]]
							sub_tab_nam <- names(sub_list)[i]
							plot_lst <- list(NULL)
							nam_sub_list <- names(mswitch_lst)[i]
							for(k in 1:length(sub_list)){
									colnams <- colnames(sub_list[[k]])[grepl("_R0", colnames(sub_list[[k]]))]
									colnams <- gsub("_child|_woman", "", colnams)
									if(identical(colnams, rownames(pheno_list[[k]]))==FALSE){stop("Sample ID's in mswitch list and phenotype files are not identical!")}
									transmat <- t(as.matrix(sub_list[[k]][,2:ncol(sub_list[[k]])])) # Transpose averaged beta values
									colnames(transmat) <- sub_list[[k]][,1]
									data_wide <- as.data.frame(cbind(pheno_list[[k]], transmat))
									data_long <- melt(data_wide, id.vars=c(1:(ncol(data_wide)-4)))
									subplot_lst <- list(NULL)
									for(z in 1:length(var)){
											x_nam <- as.character(main_fact[k])
											var_nam <- as.character(var[z])
											data <- data_long[data_long$variable==var_nam,]
											data$value <- data$value*100
											y_mean<- mean(data$value)
											y_sd <- 1.3*sd(data$value)
											y_lim <- c(y_mean-y_sd, y_mean+y_sd)
											model <- paste0("value ~ ", paste(x_nam, paste(covar_fact[[k]], collapse="+"), sep="+"))
											res <- summary(lm(formula= model, dat=data))
											p_val<- res$coefficients[2,4]
											p_val <- if(p_val<0.05){paste0("p=", format(signif(p_val, digits=1), scientific=F))} else {paste0("n.s.")}
											p <- ggplot(data, aes_string(x=x_nam, y = "value"))+ 
    											stat_summary(geom = "errorbar", aes_string(x=x_nam), fun.data = mean_se, position = "dodge", width=0.8, cex=0.4, col="#404040") +
												stat_summary(geom = "crossbar", aes_string(x=x_nam), color="red", fun.y= mean, fun.ymin = mean, fun.ymax = mean, width=0.2, cex=0.3)+ 
												coord_cartesian(ylim=y_lim)+
												facet_wrap(~variable, scales="free", ncol=2)+
												ggtitle(paste(nam_top1[i])) +
												xlab(paste(nam_dataset[k])) + 
												ylab("Mean % DNA methylation +/- SE") +
												annotate("text", x=1.5, y=(y_lim[2]-0.02), label=p_val, size = 2.5, color="blue") +
												theme(plot.title = element_text(size = 7, face = "bold"),
													  axis.title = element_text(size = 7),
													  axis.text = element_text(size = 6),
													  strip.text = element_text(size = 7))
													  subplot_lst[[z]] <- p
											names(subplot_lst)[z] <- var_nam
										}
									plot_lst[[k]] <- subplot_lst
									names(plot_lst)[k] <- sub_tab_nam
									}
						Fin_plot_lst[[i]] <- plot_lst
						names(Fin_plot_lst)[i] <- nam_sub_list
					}
				cat("\n##---------------------------------------------------------------------------------------##\n")
				cat("The output list is structured like this:\n")
				cat("\n Plot list")
				cat("\n    |                                                     |--High_No_repeat")                         
				cat("\n    |                                    |---Braz_child---|--High_Repeat")
				cat("\n    |                                    |                |--Low_No_repeat")
				cat("\n    |                                    |                |--Low_Repeats") 	
				cat("\n    |                                    |")
				cat("\n    |                                    |                |--High_No_repeat")                        
				cat("\n    |---sublist_1--top1%_Braz_children---|---Braz_women---|--High_Repeat")
				cat("\n    |                                    |                |--Low_No_repeat")
				cat("\n    |                                    |                |--Low_Repeats") 
				cat("\n    |                                    |")				   
				cat("\n    |                                    |                |--High_No_repeat")                         
				cat("\n    |                                    |---Grady_psych--|--High_Repeat")
				cat("\n    |                                                     |--Low_No_repeat")
				cat("\n    |                                                     |--Low_Repeats") 
				cat("\n    |")                                    				   
				cat("\n    |                                                     |--High_No_repeat")                         
				cat("\n    |                                    |---Braz_child---|--High_Repeat")
				cat("\n    |                                    |                |--Low_No_repeat")
				cat("\n    |                                    |                |--Low_Repeats") 	
				cat("\n    |                                    |")				   
				cat("\n    |                                    |                |--High_No_repeat")                         
				cat("\n    |---sublist_1--top1%_Braz_women------|---Braz_women---|--High_Repeat")
				cat("\n    |                                    |                |--Low_No_repeat")
				cat("\n    |                                    |                |--Low_Repeats") 
				cat("\n    |                                    |")				   
				cat("\n    |                                    |                |--High_No_repeat")                         
				cat("\n    |                                    |---Grady_psych--|--High_Repeat")
				cat("\n    |                                                     |--Low_No_repeat")
				cat("\n    |                                                     |--Low_Repeats")
				cat("\n    |")                                    				   
				cat("\n    |                                                     |--High_No_repeat")                         
				cat("\n    |                                    |---Braz_child---|--High_Repeat")
				cat("\n    |                                    |                |--Low_No_repeat")
				cat("\n    |                                    |                |--Low_Repeats") 	
				cat("\n    |                                    |")				   
				cat("\n    |                                    |                |--High_No_repeat")                         
				cat("\n    |---sublist_1--top1%_Grady_psych-----|---Braz_women---|--High_Repeat")
				cat("\n                                         |                |--Low_No_repeat")
				cat("\n                                         |                |--Low_Repeats") 
				cat("\n                                         |")				   
				cat("\n                                         |                |--High_No_repeat")                         
				cat("\n                                         |---Grady_psych--|--High_Repeat")
				cat("\n                                                          |--Low_No_repeat")
				cat("\n                                                          |--Low_Repeats") 
				cat("\n\n##---------------------------------------------------------------------------------------##\n")
				return(Fin_plot_lst)
			}
mswitch_plots_lst <- mswitch.plots(mswitch_lst, Pheno_Braz, Pheno_Grady)


##--------------------------------------------------------------------------------##
####         Print the plots
##--------------------------------------------------------------------------------##
## Description:
##			For best looking graphs use the generate.pdf function which exports 
##			selected graphs to two pdf files in your given path. In 
##			Plots_Brazilian.pdf the regenerated graphs from the Brazilian Women and 
##			Children comparison of Figure 4 in the original paper can be found. 
## 			In Plots_Grady.pdf the Grady comparison of Figure S7.
##			The script will also plot Brazilian Women and Children comparison 
##			directly as a plot in R.
## Input files:
##			path = path to a destination fold for the pdf-files.
##			mswitch_plots_lst= Output plot list from the mswitch.plots function (above).
## Output:
##			Plots_Brazilain.pdf = Methylome switching plots for Brazilian womena and children. 
##			Plots_Grady.pdf = Methylome switching plots for Grady and Brazilian children.
##			R plots for Brazilian children. 
##
##

path="<#### Path to where you want to save plot pdf ####>"
generate.pdf <- function(mswitch_plots_lst, path){
						response <- readline(prompt=cat("\nThis will create a new directory in your output path:\n    ",path,"\n\nIs it ok to proceed? [y/n]"))
						if(response=="y" | response=="Y"){
							cat("\nGenerating pdf-files.")
							plot_path <- paste0(path, "plots")
							dir.create(plot_path)
							Braz_plots <- plot_grid(plotlist=c(mswitch_plots_lst[[1]][[1]], mswitch_plots_lst[[1]][[2]], 
					 						mswitch_plots_lst[[2]][[1]], mswitch_plots_lst[[2]][[2]]), 
		  									labels = NULL, hjust = 0, vjust = 1, ncol = 4, nrow = 4)
							Grady_plots <- plot_grid(plotlist=c(mswitch_plots_lst[[3]][[1]], mswitch_plots_lst[[3]][[3]]), 
										  labels = NULL, hjust = 0, vjust = 1, ncol = 4, nrow = 4)
							pdf(file=paste0(plot_path, "/Plots_Brazilian.pdf"))
							print(Braz_plots)
							dev.off()
							pdf(file=paste0(plot_path, "/Plots_Grady.pdf"))
							print(Grady_plots)
							dev.off()
						}
					dev.off()	
					return(print(Braz_plots))
			}
generate.pdf(mswitch_plots_lst, path)

## To plot the same graphs directly in R use:
library(cowplot)
plot_grid(plotlist=c(mswitch_plots_lst[[1]][[1]], mswitch_plots_lst[[1]][[2]], mswitch_plots_lst[[2]][[1]], mswitch_plots_lst[[2]][[2]]), labels = NULL, hjust = 0, vjust = 1, ncol = 4, nrow = 4)
plot_grid(plotlist=c(mswitch_plots_lst[[3]][[3]], mswitch_plots_lst[[3]][[1]]), labels = NULL, hjust = 0, vjust = 1, ncol = 4, nrow = 4)


## Each plot can also be individually accessed by:
mswitch_plots_lst[[1]][[1]][[1]]





##--------------------------------------------------------------------------------##
####         sessionInfo
##--------------------------------------------------------------------------------##
# 
# R version 3.5.1 (2018-07-02)
#
# Matrix products: default
# 
# locale:
# [1] LC_COLLATE=English_United States.1252  LC_CTYPE=English_United States.1252    LC_MONETARY=English_United States.1252
# [4] LC_NUMERIC=C                           LC_TIME=English_United States.1252    
# 
# attached base packages:
#  [1] grid      stats4    parallel  stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#  [1] gridGraphics_0.3-0                                 cowplot_0.9.3                                     
#  [3] gridExtra_2.3                                      scater_1.8.4                                      
#  [5] SingleCellExperiment_1.2.0                         ggplot2_3.0.0                                     
#  [7] reshape_0.8.7                                      limma_3.36.3                                      
#  [9] IlluminaHumanMethylation450kanno.ilmn12.hg19_0.6.0 IlluminaHumanMethylation450kmanifest_0.4.0        
# [11] minfi_1.26.2                                       bumphunter_1.22.0                                 
# [13] locfit_1.5-9.1                                     iterators_1.0.10                                  
# [15] foreach_1.4.4                                      Biostrings_2.48.0                                 
# [17] XVector_0.20.0                                     SummarizedExperiment_1.10.1                       
# [19] DelayedArray_0.6.5                                 BiocParallel_1.14.2                               
# [21] matrixStats_0.54.0                                 GenomicRanges_1.32.6                              
# [23] GenomeInfoDb_1.16.0                                IRanges_2.14.10                                   
# [25] S4Vectors_0.18.3                                   GEOquery_2.48.0                                   
# [27] Biobase_2.40.0                                     BiocGenerics_0.26.0                               





